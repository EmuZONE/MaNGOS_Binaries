UPDATE `item_template` SET `BagFamily` = 0x00000400 WHERE `BagFamily` =11;
UPDATE `item_template` SET `BagFamily` = 0x00000200 WHERE `BagFamily` =10;
UPDATE `item_template` SET `BagFamily` = 0x00000100 WHERE `BagFamily` = 9;
UPDATE `item_template` SET `BagFamily` = 0x00000080 WHERE `BagFamily` = 8;
UPDATE `item_template` SET `BagFamily` = 0x00000040 WHERE `BagFamily` = 7;
UPDATE `item_template` SET `BagFamily` = 0x00000020 WHERE `BagFamily` = 6;
UPDATE `item_template` SET `BagFamily` = 0x00000008 WHERE `BagFamily` = 4;
UPDATE `item_template` SET `BagFamily` = 0x00000004 WHERE `BagFamily` = 3;
