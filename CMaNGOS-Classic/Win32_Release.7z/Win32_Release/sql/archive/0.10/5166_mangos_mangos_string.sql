DELETE FROM `mangos_string` WHERE `entry`= 706;
INSERT INTO `mangos_string` VALUES
(706,'This item(s) have problems with equipping/storing in inventory.',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
