DELETE FROM command where name IN ('lookup title');

INSERT INTO `command` VALUES
('lookup title',2,'Syntax: .lookup title $$namepart\r\n\r\nLooks up a title by $namepart, and returns all matches with their title ID\'s and index\'s.');
