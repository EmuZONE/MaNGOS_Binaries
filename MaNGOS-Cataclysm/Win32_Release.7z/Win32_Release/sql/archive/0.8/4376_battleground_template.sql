DELETE FROM `battleground_template` WHERE `id` IN ('5', '6');
INSERT INTO `battleground_template` VALUES ('5', '2', '10', '70', '939', '0', '940', '3.14159');
INSERT INTO `battleground_template` VALUES ('6', '2', '10', '70', '0', '0', '0', '0');
