ALTER TABLE db_version CHANGE COLUMN required_053_8190_01_mangos_creature_template required_058_7544_01_mangos_uptime bit;

DROP TABLE IF EXISTS `uptime`;
