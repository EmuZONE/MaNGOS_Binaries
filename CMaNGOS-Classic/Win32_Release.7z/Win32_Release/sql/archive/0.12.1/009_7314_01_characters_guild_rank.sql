UPDATE guild_rank SET rights = rights & ~0x00020000;
