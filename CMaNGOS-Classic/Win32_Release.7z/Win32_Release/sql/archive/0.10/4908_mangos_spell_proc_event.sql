DELETE FROM `spell_proc_event` WHERE `entry` IN (38394);
INSERT INTO `spell_proc_event` VALUES
(38394,36,0,0,5,6,131072,0);
