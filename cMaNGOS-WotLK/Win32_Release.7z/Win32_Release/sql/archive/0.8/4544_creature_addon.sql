ALTER TABLE `creature_addon`
    DROP COLUMN `RefId`;
