ALTER TABLE `auctionhouse`
  ADD UNIQUE KEY `item_guid` (`itemguid`);
