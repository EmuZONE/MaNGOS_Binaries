ALTER IGNORE TABLE `playercreateinfo_spell`
    ADD PRIMARY KEY (`createid`,`Spell`);

