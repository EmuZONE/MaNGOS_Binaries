ALTER TABLE `gameobject_template` ADD COLUMN `castBarCaption` varchar(100) NOT NULL default '' AFTER name;
