ALTER TABLE `item_instance`
    ADD KEY `idx_owner_guid` ( `owner_guid`);
