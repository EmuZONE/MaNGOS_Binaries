ALTER TABLE `creature_template`
  ADD COLUMN IconName char(100) default NULL AFTER subname;
