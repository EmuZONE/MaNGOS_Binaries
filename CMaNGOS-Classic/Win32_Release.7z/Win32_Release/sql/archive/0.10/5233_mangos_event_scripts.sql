ALTER TABLE `gameobject_scripts` RENAME TO `event_scripts`;
