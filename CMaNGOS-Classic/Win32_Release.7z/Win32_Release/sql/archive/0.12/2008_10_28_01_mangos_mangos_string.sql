DELETE FROM mangos_string WHERE entry IN (171,172);

INSERT INTO mangos_string VALUES
(172,'server console command',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
