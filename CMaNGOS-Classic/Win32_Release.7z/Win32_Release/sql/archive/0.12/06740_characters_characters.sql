ALTER TABLE characters
  CHANGE COLUMN gmstate gmstate int(11) unsigned NOT NULL default '0';
