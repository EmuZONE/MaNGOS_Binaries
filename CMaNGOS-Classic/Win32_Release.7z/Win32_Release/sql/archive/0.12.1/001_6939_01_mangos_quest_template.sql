ALTER TABLE `quest_template`
    CHANGE `RewHonorableKills` `RewHonorableKills` int unsigned NOT NULL default '0';
