DELETE FROM `spell_proc_event` WHERE `entry` IN (5728,6397,6398,6399,10425,10426,25513);
INSERT INTO `spell_proc_event` VALUES
(5728,0,0,0,0,0,1049602,0),
(6397,0,0,0,0,0,1049602,0),
(6398,0,0,0,0,0,1049602,0),
(6399,0,0,0,0,0,1049602,0),
(10425,0,0,0,0,0,1049602,0),
(10426,0,0,0,0,0,1049602,0),
(25513,0,0,0,0,0,1049602,0);

DELETE FROM `spell_proc_event` WHERE `entry` IN (31895);
INSERT INTO `spell_proc_event` VALUES
(31895,0,0,0,0,0,1,2);

DELETE FROM `spell_proc_event` WHERE `entry` IN (37705);
INSERT INTO `spell_proc_event` VALUES
(37705,0,0,0,0,0,134217728,0);

DELETE FROM `spell_proc_event` WHERE `entry` IN (37247);
INSERT INTO `spell_proc_event` VALUES
(37247,8,0,0,0,0,16384,0);

DELETE FROM `spell_proc_event` WHERE `entry` IN (40444);
INSERT INTO `spell_proc_event` VALUES
(40444,0,0,0,0,0,64,0);

DELETE FROM `spell_proc_event` WHERE `entry` IN (40482);
INSERT INTO `spell_proc_event` VALUES
(40482,0,0,0,0,0,65536,0);

DELETE FROM `spell_proc_event` WHERE `entry` IN (33297);
INSERT INTO `spell_proc_event` VALUES
(33297,0,0,0,0,0,131072,0);

DELETE FROM `spell_proc_event` WHERE `entry` IN (33953);
INSERT INTO `spell_proc_event` VALUES
(33953,0,0,0,0,0,134217728,0);

DELETE FROM `spell_proc_event` WHERE `entry` IN (38350);
INSERT INTO `spell_proc_event` VALUES
(38350,0,0,0,0,0,4198400,0);

DELETE FROM `spell_proc_event` WHERE `entry` IN (33510);
INSERT INTO `spell_proc_event` VALUES
(33510,0,0,0,0,0,524289,5);

DELETE FROM `spell_proc_event` WHERE `entry` IN (32215);
INSERT INTO `spell_proc_event` VALUES
(32215,0,0,0,0,0,4,0);
