DELETE FROM command WHERE name IN ('repairitems');

INSERT INTO command VALUES
('repairitems',2,'Syntax: .repairitems\r\n\r\nRepair all selected player''s items.');
