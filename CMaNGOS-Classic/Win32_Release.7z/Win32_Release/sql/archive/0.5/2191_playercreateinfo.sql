ALTER TABLE `playercreateinfo`
    DROP `attackpower`,
    DROP `mindmg`,
    DROP `maxdmg`,
    DROP `ranmindmg`,
    DROP `ranmaxdmg`;
