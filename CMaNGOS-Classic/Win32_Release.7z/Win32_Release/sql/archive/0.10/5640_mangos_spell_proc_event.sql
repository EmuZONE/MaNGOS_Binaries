DELETE FROM `spell_proc_event` WHERE `entry`=24905;
INSERT INTO `spell_proc_event` ( `entry` , `SchoolMask` , `Category` , `SkillID` , `SpellFamilyName` , `SpellFamilyMask` , `procFlags` , `ppmRate` ) VALUES
('24905', '0', '0', '0', '0', '0', '1', '15');
