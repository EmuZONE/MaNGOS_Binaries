DELETE FROM `spell_proc_event` WHERE `entry` IN (14796, 16146);
