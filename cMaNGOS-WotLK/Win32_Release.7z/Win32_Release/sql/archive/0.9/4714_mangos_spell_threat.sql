/*Heroic Strike*/
INSERT INTO `spell_threat` (`entry`, `Threat`) VALUES ('29707', '196');
INSERT INTO `spell_threat` (`entry`, `Threat`) VALUES ('30324', '220');
/*Maul*/
INSERT INTO `spell_threat` (`entry`, `Threat`) VALUES ('26996', '176');
/*Shield Slam*/
INSERT INTO `spell_threat` (`entry`, `Threat`) VALUES ('25258', '286');
INSERT INTO `spell_threat` (`entry`, `Threat`) VALUES ('30356', '323');
/*Revenge*/
INSERT INTO `spell_threat` (`entry`, `Threat`) VALUES ('25269', '400');
INSERT INTO `spell_threat` (`entry`, `Threat`) VALUES ('30357', '483');
/*Shield Bash*/
INSERT INTO `spell_threat` (`entry`, `Threat`) VALUES ('29704', '230');
/*Sunder Armor*/
INSERT INTO `spell_threat` (`entry`, `Threat`) VALUES ('25225', '300');
/*Cleave*/
INSERT INTO `spell_threat` (`entry`, `Threat`) VALUES ('20569', '100');
INSERT INTO `spell_threat` (`entry`, `Threat`) VALUES ('25231', '130');
/*Lacerate*/
INSERT INTO `spell_threat` (`entry`, `Threat`) VALUES ('33745', '285');
/*Faerie Fire*/
INSERT INTO `spell_threat` (`entry`, `Threat`) VALUES ('26993', '127');
/*Faerie Fire(feral)*/
INSERT INTO `spell_threat` (`entry`, `Threat`) VALUES ('16857', '108');
INSERT INTO `spell_threat` (`entry`, `Threat`) VALUES ('17390', '108');
INSERT INTO `spell_threat` (`entry`, `Threat`) VALUES ('17391', '108');
INSERT INTO `spell_threat` (`entry`, `Threat`) VALUES ('17392', '108');
INSERT INTO `spell_threat` (`entry`, `Threat`) VALUES ('27011', '127');
/*Thunder Clap: multiplier = 1.75*/
INSERT INTO `spell_threat` (`entry`, `Threat`) VALUES ('6343', '17');
INSERT INTO `spell_threat` (`entry`, `Threat`) VALUES ('8198', '40');
INSERT INTO `spell_threat` (`entry`, `Threat`) VALUES ('8204', '64');
INSERT INTO `spell_threat` (`entry`, `Threat`) VALUES ('8205', '96');
INSERT INTO `spell_threat` (`entry`, `Threat`) VALUES ('11580', '143');
INSERT INTO `spell_threat` (`entry`, `Threat`) VALUES ('11581', '180');
INSERT INTO `spell_threat` (`entry`, `Threat`) VALUES ('25264', '215');
/*Mangle (Bear): multiplier = 1.5*/
INSERT INTO `spell_threat` (`entry`, `Threat`) VALUES ('33878', '129');
INSERT INTO `spell_threat` (`entry`, `Threat`) VALUES ('33986', '180');
INSERT INTO `spell_threat` (`entry`, `Threat`) VALUES ('33987', '232');
/*Holy Shield: multiplier = 0.35*/
INSERT INTO `spell_threat` (`entry`, `Threat`) VALUES ('20925', '20');
INSERT INTO `spell_threat` (`entry`, `Threat`) VALUES ('20927', '30');
INSERT INTO `spell_threat` (`entry`, `Threat`) VALUES ('20928', '40');
INSERT INTO `spell_threat` (`entry`, `Threat`) VALUES ('27179', '54');
