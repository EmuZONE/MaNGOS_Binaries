DELETE FROM `spell_proc_event` WHERE `entry` IN ( 12958, 12311 );
INSERT INTO `spell_proc_event` VALUES
(12958,0,0,0,4,0x800,0x20000,0),
(12311,0,0,0,4,0x800,0x20000,0);
