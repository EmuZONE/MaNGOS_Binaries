DELETE FROM mangos_string WHERE entry IN(1200,1201);
INSERT INTO mangos_string VALUES
(1200,'You try to view cinemitic %u but it doesn\'t exist.',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
