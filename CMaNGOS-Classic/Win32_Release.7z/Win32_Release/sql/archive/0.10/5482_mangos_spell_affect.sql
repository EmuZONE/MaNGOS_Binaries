ALTER TABLE spell_affect
    DROP SpellId,
    DROP SchoolMask,
    DROP Category,
    DROP SkillID;
