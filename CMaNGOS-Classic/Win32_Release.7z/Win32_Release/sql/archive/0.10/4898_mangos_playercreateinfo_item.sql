INSERT IGNORE INTO `playercreateinfo_item` VALUES (11, 8, 6948, 1);
