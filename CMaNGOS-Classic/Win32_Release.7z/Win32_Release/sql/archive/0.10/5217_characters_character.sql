ALTER TABLE `character`
  ADD COLUMN `taxi_path` text;
