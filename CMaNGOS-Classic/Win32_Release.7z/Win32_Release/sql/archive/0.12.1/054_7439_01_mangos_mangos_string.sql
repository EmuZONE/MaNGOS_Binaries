DELETE FROM mangos_string WHERE entry in (175);
INSERT INTO mangos_string VALUES
 (175,'Liquid level: %f, ground: %f, type: %d, status: %d',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
