DELETE FROM spell_learn_spell WHERE entry IN (33943);
INSERT INTO spell_learn_spell VALUES (33943,34090,0);
