UPDATE spell_proc_event SET ppmRate = 20 WHERE entry IN (20166,20356,20357,27166);
UPDATE spell_proc_event SET ppmRate = 20 WHERE entry IN (20165,20347,20348,20349,27160);
