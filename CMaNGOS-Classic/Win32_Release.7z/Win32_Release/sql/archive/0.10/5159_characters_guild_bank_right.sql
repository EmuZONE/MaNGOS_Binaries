ALTER TABLE `guild_bank_right`
  ADD KEY `guildid_key` (`guildid`);

