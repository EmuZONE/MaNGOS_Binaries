DELETE FROM mangos_string WHERE entry in (468,470);
INSERT INTO mangos_string VALUES
(468,'id: %d eff: %d type: %d duration: %d maxduration: %d name: %s caster: %s %u',NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(470,'id: %d eff: %d name: %s caster: %s %u',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
