DELETE FROM `spell_affect` WHERE `entry` IN (30288);
INSERT INTO `spell_affect` VALUES (30288, 0, 0, 0x00, 0, 0, 0, 0x0000004000000001, 0);

DELETE FROM `spell_affect` WHERE `entry` IN (30289);
INSERT INTO `spell_affect` VALUES (30289, 0, 0, 0x00, 0, 0, 0, 0x0000004000000001, 0);

DELETE FROM `spell_affect` WHERE `entry` IN (30290);
INSERT INTO `spell_affect` VALUES (30290, 0, 0, 0x00, 0, 0, 0, 0x0000004000000001, 0);

DELETE FROM `spell_affect` WHERE `entry` IN (30291);
INSERT INTO `spell_affect` VALUES (30291, 0, 0, 0x00, 0, 0, 0, 0x0000004000000001, 0);

DELETE FROM `spell_affect` WHERE `entry` IN (30292);
INSERT INTO `spell_affect` VALUES (30292, 0, 0, 0x00, 0, 0, 0, 0x0000004000000001, 0);

DELETE FROM `spell_affect` WHERE `entry` IN (18427);
INSERT INTO `spell_affect` VALUES (18427, 0, 0, 0x00, 0, 0, 0, 0x0000000000020006, 0);

DELETE FROM `spell_affect` WHERE `entry` IN (18428);
INSERT INTO `spell_affect` VALUES (18428, 0, 0, 0x00, 0, 0, 0, 0x0000000000020006, 0);

DELETE FROM `spell_affect` WHERE `entry` IN (18429);
INSERT INTO `spell_affect` VALUES (18429, 0, 0, 0x00, 0, 0, 0, 0x0000000000020006, 0);

DELETE FROM `spell_affect` WHERE `entry` IN (31216);
INSERT INTO `spell_affect` VALUES (31216, 1, 0, 0x00, 0, 0, 0, 0x0000000002000004, 0);

DELETE FROM `spell_affect` WHERE `entry` IN (31217);
INSERT INTO `spell_affect` VALUES (31217, 1, 0, 0x00, 0, 0, 0, 0x0000000002000004, 0);

DELETE FROM `spell_affect` WHERE `entry` IN (31218);
INSERT INTO `spell_affect` VALUES (31218, 1, 0, 0x00, 0, 0, 0, 0x0000000002000004, 0);

DELETE FROM `spell_affect` WHERE `entry` IN (31219);
INSERT INTO `spell_affect` VALUES (31219, 1, 0, 0x00, 0, 0, 0, 0x0000000002000004, 0);

DELETE FROM `spell_affect` WHERE `entry` IN (31220);
INSERT INTO `spell_affect` VALUES (31220, 1, 0, 0x00, 0, 0, 0, 0x0000000002000004, 0);

DELETE FROM `spell_affect` WHERE `entry` IN (14171);
INSERT INTO `spell_affect` VALUES (14171, 0, 0, 0x00, 0, 0, 0, 0x0000000000100000, 0);

DELETE FROM `spell_affect` WHERE `entry` IN (14172);
INSERT INTO `spell_affect` VALUES (14172, 0, 0, 0x00, 0, 0, 0, 0x0000000000100000, 0);

DELETE FROM `spell_affect` WHERE `entry` IN (14173);
INSERT INTO `spell_affect` VALUES (14173, 0, 0, 0x00, 0, 0, 0, 0x0000000000100000, 0);

DELETE FROM `spell_affect` WHERE `entry` IN (12290);
INSERT INTO `spell_affect` VALUES (12290, 0, 0, 0x00, 0, 0, 0, 0x0000000000000004, 0);

DELETE FROM `spell_affect` WHERE `entry` IN (12963);
INSERT INTO `spell_affect` VALUES (12963, 0, 0, 0x00, 0, 0, 0, 0x0000000000000004, 0);
