DELETE FROM `spell_proc_event` WHERE `entry` IN ( 37239 );
INSERT INTO `spell_proc_event` VALUES
(37239,0,0,0,0,0x0000000000000000,0x00000001,0);

DELETE FROM `spell_proc_event` WHERE `entry` IN ( 43737 );
INSERT INTO `spell_proc_event` VALUES
(43737,0,0,0,7,0x0000044000000000,0x00000001,0);

DELETE FROM `spell_proc_event` WHERE `entry` IN ( 43739 );
INSERT INTO `spell_proc_event` VALUES
(43739,0,0,0,7,0x0000000000000002,0x00020000,0);
