DELETE FROM `spell_proc_event` WHERE `entry` IN (34774, 34586);
INSERT INTO `spell_proc_event` VALUES
(34586,0,0,0,0,0,524289,1.5),
(34774,0,0,0,0,0,524289,1.5);
