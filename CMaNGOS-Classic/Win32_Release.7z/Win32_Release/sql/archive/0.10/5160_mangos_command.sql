DELETE FROM command WHERE name IN ('info');

INSERT INTO `command` VALUES
('info',0,'Syntax: .info\r\n\r\nDisplay server version and the number of connected players.');
