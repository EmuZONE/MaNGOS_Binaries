DELETE FROM `spell_learn_skill` WHERE `entry` IN (29932);
INSERT INTO `spell_learn_skill` (`entry`, `SkillID`, `Value`, `MaxValue`) VALUE
(29932,759,-1,-1);
