DELETE FROM `spell_proc_event` WHERE `entry` IN (32642);
INSERT INTO `spell_proc_event` VALUES
(32642,0,0,0,0,0,64,0);
