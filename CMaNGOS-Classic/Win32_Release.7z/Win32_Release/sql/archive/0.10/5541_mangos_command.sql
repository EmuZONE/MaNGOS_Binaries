DELETE FROM `command` WHERE `name` = 'learn all_default';

INSERT INTO `command` VALUES
('learn all_default',1,'Syntax: .learn all_default [$playername]\r\n\r\nLearn for selected/$playername player all default spells for his race/class and spells rewarded by completed quests.');

