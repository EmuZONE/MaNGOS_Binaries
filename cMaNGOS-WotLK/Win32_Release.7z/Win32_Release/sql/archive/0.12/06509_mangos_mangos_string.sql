DELETE FROM mangos_string WHERE entry IN (592);
INSERT INTO mangos_string VALUES
(592,'You have learned all spells in craft: %s',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
