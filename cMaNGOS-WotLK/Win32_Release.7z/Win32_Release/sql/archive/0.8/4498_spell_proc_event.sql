DELETE FROM `spell_proc_event` WHERE `entry` IN (40971);
INSERT INTO `spell_proc_event` VALUES
(40971,0,0,0,0,0,134217728,0);

DELETE FROM `spell_proc_event` WHERE `entry` IN (38427,40407);
INSERT INTO `spell_proc_event` VALUES
(38427,0,0,0,0,0,1,0),
(40407,0,0,0,0,0,1026,6);
