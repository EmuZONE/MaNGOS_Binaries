UPDATE `character_spell`
  SET `spell` = 5420 WHERE `spell` = 3122;
