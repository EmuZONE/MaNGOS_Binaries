ALTER TABLE `creature_movement` CHANGE COLUMN `text1` `text1` text;
ALTER TABLE `creature_movement` CHANGE COLUMN `text2` `text2` text;
ALTER TABLE `creature_movement` CHANGE COLUMN `text3` `text3` text;
ALTER TABLE `creature_movement` CHANGE COLUMN `text4` `text4` text;
ALTER TABLE `creature_movement` CHANGE COLUMN `text5` `text5` text;
