INSERT INTO `spell_learn_spell` ( `entry` , `SpellID` , `IfNoSpell` ) VALUES
('17002', '24867', '0'),
('24866', '24864', '0');
