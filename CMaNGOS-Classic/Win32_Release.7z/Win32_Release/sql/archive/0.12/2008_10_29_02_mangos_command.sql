DELETE FROM command WHERE name IN ('waterwalk');

INSERT INTO command VALUES
('waterwalk',3,'Syntax: .waterwalk on/off\r\n\r\nSet on/off waterwalk state for selected player.');
