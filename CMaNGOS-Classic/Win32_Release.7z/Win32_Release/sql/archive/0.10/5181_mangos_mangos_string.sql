DELETE FROM `mangos_string` WHERE `entry` = 548;
INSERT INTO `mangos_string` VALUES
 (548,'Player%s %s (guid: %u) Account: %s (id: %u) GMLevel: %u Last IP: %s Latency: %ums',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
