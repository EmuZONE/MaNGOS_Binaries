ALTER TABLE realmd.realmlist
    ALTER COLUMN `color` SET DEFAULT '2',
    ENGINE = MyISAM;
