ALTER TABLE `quest_template` CHANGE COLUMN `RewXpOrMoney` `RewMoneyMaxLevel` int(11) unsigned NOT NULL default '0';
