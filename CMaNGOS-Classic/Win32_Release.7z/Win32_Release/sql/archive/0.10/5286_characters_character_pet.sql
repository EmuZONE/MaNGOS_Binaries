ALTER TABLE `character_pet`
  DROP `nextlvlexp`;
