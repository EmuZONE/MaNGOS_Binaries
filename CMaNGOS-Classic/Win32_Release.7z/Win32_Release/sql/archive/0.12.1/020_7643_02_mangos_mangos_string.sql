DELETE FROM mangos_string WHERE entry IN(59);
INSERT INTO mangos_string VALUES
(59,'Using creature EventAI: %s',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
