DELETE FROM `spell_threat` WHERE `entry` = 2139;
INSERT INTO `spell_threat` (`entry`, `Threat`) VALUES
(2139, 300);
