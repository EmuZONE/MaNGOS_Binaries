DELETE FROM `spell_proc_event` WHERE `entry` IN (2565);
INSERT INTO `spell_proc_event` VALUES
(2565,0,0,0,0,0,64,0);

