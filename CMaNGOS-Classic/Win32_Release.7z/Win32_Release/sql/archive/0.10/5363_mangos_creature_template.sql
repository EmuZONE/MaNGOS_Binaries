ALTER TABLE `creature_template`
    ADD `scale` float default '0' AFTER `speed`;
