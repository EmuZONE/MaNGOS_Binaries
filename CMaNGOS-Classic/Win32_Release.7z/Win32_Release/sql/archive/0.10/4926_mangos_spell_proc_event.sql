DELETE FROM `spell_proc_event` WHERE `entry` IN (40458);
INSERT INTO `spell_proc_event` VALUES
(40458,0,971,0,4,0x60102000000,1,0);
