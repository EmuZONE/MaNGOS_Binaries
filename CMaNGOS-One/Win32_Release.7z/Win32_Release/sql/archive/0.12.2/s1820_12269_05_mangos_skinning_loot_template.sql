ALTER TABLE db_version CHANGE COLUMN required_s1820_12269_04_mangos_reference_loot_template required_s1820_12269_05_mangos_skinning_loot_template bit;

ALTER TABLE skinning_loot_template DROP COLUMN lootcondition, DROP COLUMN condition_value1, DROP COLUMN condition_value2;
