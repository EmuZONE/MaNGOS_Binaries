DELETE FROM `spell_proc_event` WHERE `entry` IN ( 37514 );
INSERT INTO `spell_proc_event` (`entry` ,`SchoolMask`,`Category`,`SkillID`,`SpellFamilyName`,`SpellFamilyMask`,`procFlags`,`ppmRate`)
VALUES ('37514', '0', '0', '0', '0', '0', '32', '0');

DELETE FROM `spell_proc_event` WHERE `entry` IN ( 37197 );
INSERT INTO `spell_proc_event` (`entry` ,`SchoolMask`,`Category`,`SkillID`,`SpellFamilyName`,`SpellFamilyMask`,`procFlags`,`ppmRate`)
VALUES ('37197', '0', '0', '0', '0', '0', '16384', '0');
