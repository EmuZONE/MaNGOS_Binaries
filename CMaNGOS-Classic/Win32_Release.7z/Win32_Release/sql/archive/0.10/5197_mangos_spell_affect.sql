DELETE FROM `spell_affect` WHERE `entry` IN (33167);
INSERT INTO `spell_affect` VALUES (33167, 0, 0, 0x00, 0, 0, 0, 0x0000000100000000, 0);

DELETE FROM `spell_affect` WHERE `entry` IN (33171);
INSERT INTO `spell_affect` VALUES (33171, 0, 0, 0x00, 0, 0, 0, 0x0000000100000000, 0);

DELETE FROM `spell_affect` WHERE `entry` IN (33172);
INSERT INTO `spell_affect` VALUES (33172, 0, 0, 0x00, 0, 0, 0, 0x0000000100000000, 0);

DELETE FROM `spell_affect` WHERE `entry` IN (23236);
INSERT INTO `spell_affect` VALUES (23236, 0, 0, 0x00, 0, 0, 0, 0x0000003419541EC0, 0);

DELETE FROM `spell_affect` WHERE `entry` IN (37880);
INSERT INTO `spell_affect` VALUES (37880, 0, 0, 0x00, 0, 0, 0, 0x0000000411041E40, 0);

DELETE FROM `spell_affect` WHERE `entry` IN (15259);
INSERT INTO `spell_affect` VALUES (15259, 0, 0, 0x00, 0, 0, 0, 0x0000000202002000, 0);
INSERT INTO `spell_affect` VALUES (15259, 1, 0, 0x00, 0, 0, 0, 0x0000040000808000, 0);

DELETE FROM `spell_affect` WHERE `entry` IN (15307);
INSERT INTO `spell_affect` VALUES (15307, 0, 0, 0x00, 0, 0, 0, 0x0000000202002000, 0);
INSERT INTO `spell_affect` VALUES (15307, 1, 0, 0x00, 0, 0, 0, 0x0000040000808000, 0);

DELETE FROM `spell_affect` WHERE `entry` IN (15308);
INSERT INTO `spell_affect` VALUES (15308, 0, 0, 0x00, 0, 0, 0, 0x0000000202002000, 0);
INSERT INTO `spell_affect` VALUES (15308, 1, 0, 0x00, 0, 0, 0, 0x0000040000808000, 0);

DELETE FROM `spell_affect` WHERE `entry` IN (15309);
INSERT INTO `spell_affect` VALUES (15309, 0, 0, 0x00, 0, 0, 0, 0x0000000202002000, 0);
INSERT INTO `spell_affect` VALUES (15309, 1, 0, 0x00, 0, 0, 0, 0x0000040000808000, 0);

DELETE FROM `spell_affect` WHERE `entry` IN (15310);
INSERT INTO `spell_affect` VALUES (15310, 0, 0, 0x00, 0, 0, 0, 0x0000000202002000, 0);
INSERT INTO `spell_affect` VALUES (15310, 1, 0, 0x00, 0, 0, 0, 0x0000040000808000, 0);

DELETE FROM `spell_affect` WHERE `entry` IN (14743);
INSERT INTO `spell_affect` VALUES (14743, 0, 0, 0x00, 0, 0, 0, 0x0000049440963E90, 0);

DELETE FROM `spell_affect` WHERE `entry` IN (27828);
INSERT INTO `spell_affect` VALUES (27828, 0, 0, 0x00, 0, 0, 0, 0x0000049440963E90, 0);

DELETE FROM `spell_affect` WHERE `entry` IN (33186);
INSERT INTO `spell_affect` VALUES (33186, 0, 0, 0x00, 0, 0, 0, 0x0000008000000000, 0);
INSERT INTO `spell_affect` VALUES (33186, 1, 0, 0x00, 0, 0, 0, 0x0000008000002080, 0);

DELETE FROM `spell_affect` WHERE `entry` IN (33190);
INSERT INTO `spell_affect` VALUES (33190, 0, 0, 0x00, 0, 0, 0, 0x0000008000000000, 0);
INSERT INTO `spell_affect` VALUES (33190, 1, 0, 0x00, 0, 0, 0, 0x0000008000002080, 0);

DELETE FROM `spell_affect` WHERE `entry` IN (18544);
INSERT INTO `spell_affect` VALUES (18544, 0, 0, 0x00, 0, 0, 0, 0x0000041202F8A090, 0);
INSERT INTO `spell_affect` VALUES (18544, 1, 0, 0x00, 0, 0, 0, 0x0000001202582090, 0);
INSERT INTO `spell_affect` VALUES (18544, 2, 0, 0x00, 0, 0, 0, 0x0000040000A08000, 0);

DELETE FROM `spell_affect` WHERE `entry` IN (18547);
INSERT INTO `spell_affect` VALUES (18547, 0, 0, 0x00, 0, 0, 0, 0x0000041202F8A090, 0);
INSERT INTO `spell_affect` VALUES (18547, 1, 0, 0x00, 0, 0, 0, 0x0000001202582090, 0);
INSERT INTO `spell_affect` VALUES (18547, 2, 0, 0x00, 0, 0, 0, 0x0000040000A08000, 0);

DELETE FROM `spell_affect` WHERE `entry` IN (18548);
INSERT INTO `spell_affect` VALUES (18548, 0, 0, 0x00, 0, 0, 0, 0x0000041202F8A090, 0);
INSERT INTO `spell_affect` VALUES (18548, 1, 0, 0x00, 0, 0, 0, 0x0000001202582090, 0);
INSERT INTO `spell_affect` VALUES (18548, 2, 0, 0x00, 0, 0, 0, 0x0000040000A08000, 0);

DELETE FROM `spell_affect` WHERE `entry` IN (18549);
INSERT INTO `spell_affect` VALUES (18549, 0, 0, 0x00, 0, 0, 0, 0x0000041202F8A090, 0);
INSERT INTO `spell_affect` VALUES (18549, 1, 0, 0x00, 0, 0, 0, 0x0000001202582090, 0);
INSERT INTO `spell_affect` VALUES (18549, 2, 0, 0x00, 0, 0, 0, 0x0000040000A08000, 0);

DELETE FROM `spell_affect` WHERE `entry` IN (18550);
INSERT INTO `spell_affect` VALUES (18550, 0, 0, 0x00, 0, 0, 0, 0x0000041202F8A090, 0);
INSERT INTO `spell_affect` VALUES (18550, 1, 0, 0x00, 0, 0, 0, 0x0000001202582090, 0);
INSERT INTO `spell_affect` VALUES (18550, 2, 0, 0x00, 0, 0, 0, 0x0000040000A08000, 0);

DELETE FROM `spell_affect` WHERE `entry` IN (14913);
INSERT INTO `spell_affect` VALUES (14913, 0, 0, 0x00, 0, 0, 0, 0x0000000400041E00, 0);

DELETE FROM `spell_affect` WHERE `entry` IN (15012);
INSERT INTO `spell_affect` VALUES (15012, 0, 0, 0x00, 0, 0, 0, 0x0000000400041E00, 0);

DELETE FROM `spell_affect` WHERE `entry` IN (37706);
INSERT INTO `spell_affect` VALUES (37706, 0, 0, 0x00, 0, 0, 0, 0x0000000411041E40, 0);

DELETE FROM `spell_affect` WHERE `entry` IN (37571);
INSERT INTO `spell_affect` VALUES (37571, 0, 0, 0x00, 0, 0, 0, 0x0000000000000080, 0);
INSERT INTO `spell_affect` VALUES (37571, 1, 0, 0x00, 0, 0, 0, 0x0000000000800000, 0);

DELETE FROM `spell_affect` WHERE `entry` IN (14751);
INSERT INTO `spell_affect` VALUES (14751, 0, 0, 0x00, 0, 0, 0, 0xFFFFFFFFFFFFFFFF, 0);
INSERT INTO `spell_affect` VALUES (14751, 1, 0, 0x00, 0, 0, 0, 0xFFFFFFFFFFFFFFFF, 0);

DELETE FROM `spell_affect` WHERE `entry` IN (14520);
INSERT INTO `spell_affect` VALUES (14520, 0, 0, 0x00, 0, 0, 0, 0x00000963BF61C16F, 0);

DELETE FROM `spell_affect` WHERE `entry` IN (14780);
INSERT INTO `spell_affect` VALUES (14780, 0, 0, 0x00, 0, 0, 0, 0x00000963BF61C16F, 0);

DELETE FROM `spell_affect` WHERE `entry` IN (14781);
INSERT INTO `spell_affect` VALUES (14781, 0, 0, 0x00, 0, 0, 0, 0x00000963BF61C16F, 0);

DELETE FROM `spell_affect` WHERE `entry` IN (14782);
INSERT INTO `spell_affect` VALUES (14782, 0, 0, 0x00, 0, 0, 0, 0x00000963BF61C16F, 0);

DELETE FROM `spell_affect` WHERE `entry` IN (14783);
INSERT INTO `spell_affect` VALUES (14783, 0, 0, 0x00, 0, 0, 0, 0x00000963BF61C16F, 0);

DELETE FROM `spell_affect` WHERE `entry` IN (28808);
INSERT INTO `spell_affect` VALUES (28808, 0, 0, 0x00, 0, 0, 0, 0x0000000411041E40, 0);

DELETE FROM `spell_affect` WHERE `entry` IN (15318);
INSERT INTO `spell_affect` VALUES (15318, 0, 0, 0x00, 0, 0, 0, 0x00000D4A068BE104, 0);

DELETE FROM `spell_affect` WHERE `entry` IN (15272);
INSERT INTO `spell_affect` VALUES (15272, 0, 0, 0x00, 0, 0, 0, 0x00000D4A068BE104, 0);

DELETE FROM `spell_affect` WHERE `entry` IN (15320);
INSERT INTO `spell_affect` VALUES (15320, 0, 0, 0x00, 0, 0, 0, 0x00000D4A068BE104, 0);

DELETE FROM `spell_affect` WHERE `entry` IN (15260);
INSERT INTO `spell_affect` VALUES (15260, 0, 0, 0x00, 0, 0, 0, 0x00000442068BA000, 0);

DELETE FROM `spell_affect` WHERE `entry` IN (15327);
INSERT INTO `spell_affect` VALUES (15327, 0, 0, 0x00, 0, 0, 0, 0x00000442068BA000, 0);

DELETE FROM `spell_affect` WHERE `entry` IN (15328);
INSERT INTO `spell_affect` VALUES (15328, 0, 0, 0x00, 0, 0, 0, 0x00000442068BA000, 0);

DELETE FROM `spell_affect` WHERE `entry` IN (15329);
INSERT INTO `spell_affect` VALUES (15329, 0, 0, 0x00, 0, 0, 0, 0x00000442068BA000, 0);

DELETE FROM `spell_affect` WHERE `entry` IN (15330);
INSERT INTO `spell_affect` VALUES (15330, 0, 0, 0x00, 0, 0, 0, 0x00000442068BA000, 0);

DELETE FROM `spell_affect` WHERE `entry` IN (17322);
INSERT INTO `spell_affect` VALUES (17322, 0, 0, 0x00, 0, 0, 0, 0x00000542068AA004, 0);

DELETE FROM `spell_affect` WHERE `entry` IN (17323);
INSERT INTO `spell_affect` VALUES (17323, 0, 0, 0x00, 0, 0, 0, 0x00000542068AA004, 0);

DELETE FROM `spell_affect` WHERE `entry` IN (14523);
INSERT INTO `spell_affect` VALUES (14523, 1, 0, 0x00, 0, 0, 0, 0xFFFFFFFFFFFFFFFF, 0);

DELETE FROM `spell_affect` WHERE `entry` IN (14784);
INSERT INTO `spell_affect` VALUES (14784, 1, 0, 0x00, 0, 0, 0, 0xFFFFFFFFFFFFFFFF, 0);

DELETE FROM `spell_affect` WHERE `entry` IN (14785);
INSERT INTO `spell_affect` VALUES (14785, 1, 0, 0x00, 0, 0, 0, 0xFFFFFFFFFFFFFFFF, 0);

DELETE FROM `spell_affect` WHERE `entry` IN (14786);
INSERT INTO `spell_affect` VALUES (14786, 1, 0, 0x00, 0, 0, 0, 0xFFFFFFFFFFFFFFFF, 0);

DELETE FROM `spell_affect` WHERE `entry` IN (14787);
INSERT INTO `spell_affect` VALUES (14787, 1, 0, 0x00, 0, 0, 0, 0xFFFFFFFFFFFFFFFF, 0);

DELETE FROM `spell_affect` WHERE `entry` IN (14912);
INSERT INTO `spell_affect` VALUES (14912, 0, 0, 0x00, 0, 0, 0, 0x0000000000041400, 0);

DELETE FROM `spell_affect` WHERE `entry` IN (15013);
INSERT INTO `spell_affect` VALUES (15013, 0, 0, 0x00, 0, 0, 0, 0x0000000000041400, 0);

DELETE FROM `spell_affect` WHERE `entry` IN (15014);
INSERT INTO `spell_affect` VALUES (15014, 0, 0, 0x00, 0, 0, 0, 0x0000000000041400, 0);

DELETE FROM `spell_affect` WHERE `entry` IN (14747);
INSERT INTO `spell_affect` VALUES (14747, 0, 0, 0x00, 0, 0, 0, 0x0000000000000002, 0);

DELETE FROM `spell_affect` WHERE `entry` IN (14770);
INSERT INTO `spell_affect` VALUES (14770, 0, 0, 0x00, 0, 0, 0, 0x0000000000000002, 0);

DELETE FROM `spell_affect` WHERE `entry` IN (14771);
INSERT INTO `spell_affect` VALUES (14771, 0, 0, 0x00, 0, 0, 0, 0x0000000000000002, 0);

DELETE FROM `spell_affect` WHERE `entry` IN (44297);
INSERT INTO `spell_affect` VALUES (44297, 0, 0, 0x00, 0, 0, 0, 0x0000000000010000, 0);

