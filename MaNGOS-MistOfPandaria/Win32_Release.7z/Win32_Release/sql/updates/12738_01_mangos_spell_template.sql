ALTER TABLE db_version CHANGE COLUMN required_12712_02_mangos_command required_12738_01_mangos_spell_template bit;

DROP TABLE IF EXISTS `spell_template`;