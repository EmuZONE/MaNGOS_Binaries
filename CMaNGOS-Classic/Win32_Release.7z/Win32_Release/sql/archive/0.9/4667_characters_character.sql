ALTER TABLE `character`
  DROP COLUMN `pending_kills`;
