DELETE FROM `spell_proc_event` WHERE `entry` IN (32837);
INSERT INTO `spell_proc_event` VALUES
(32837,0,0,0,0,0,16384,0);

DELETE FROM `spell_proc_event` WHERE `entry` IN (588,7128,602,1006,10951,10952,25431);
INSERT INTO `spell_proc_event` VALUES
(588,0,0,0,0,0,1026,0),
(602,0,0,0,0,0,1026,0),
(1006,0,0,0,0,0,1026,0),
(7128,0,0,0,0,0,1026,0),
(10951,0,0,0,0,0,1026,0),
(10952,0,0,0,0,0,1026,0),
(25431,0,0,0,0,0,1026,0);
