DELETE FROM mangos_string WHERE entry IN(171,283);

INSERT INTO mangos_string VALUES
(171,'You can\'t teleport self to self!',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
