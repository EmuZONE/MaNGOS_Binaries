ALTER TABLE `creature_template`
ADD `mechanic_immune_mask` int(11) signed NOT NULL default '0' AFTER `equipment_id` ;
