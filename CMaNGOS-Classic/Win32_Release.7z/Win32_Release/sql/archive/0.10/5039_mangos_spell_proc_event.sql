DELETE FROM `spell_proc_event` WHERE `entry` IN (21890);
INSERT INTO `spell_proc_event` VALUES
 (21890,0,0,0,4,0x0000036C2A764EEF,0x00004001,0);
