DELETE FROM `spell_proc_event` WHERE `entry` IN ( 9799, 25988 );
INSERT INTO `spell_proc_event` VALUES
( 9799,0,0,0,0, 262144,0),
(25988,0,0,0,0, 262144,0);
