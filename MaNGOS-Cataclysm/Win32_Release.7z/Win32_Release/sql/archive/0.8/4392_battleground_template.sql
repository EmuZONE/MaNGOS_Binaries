DELETE FROM `battleground_template` WHERE `id`='8';
INSERT INTO `battleground_template` VALUES ('8', '2', '10', '70', '1258', '0', '1259', '3.14159');
