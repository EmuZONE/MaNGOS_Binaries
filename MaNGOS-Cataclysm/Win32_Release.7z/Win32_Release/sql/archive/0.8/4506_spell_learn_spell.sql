INSERT IGNORE INTO `spell_learn_spell` VALUES
(71,355,0),
(71,7386,0),
(264,3018,0),
(266,3018,0),
(5011,3018,0);
