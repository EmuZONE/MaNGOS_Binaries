DELETE FROM mangos_string WHERE entry in (12);
INSERT INTO mangos_string VALUES
(12,'Online players: %u (max: %u) Queued players: %u (max: %u)',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
