ALTER TABLE `guild_bank_tab`
  ADD KEY `guildid_key` (`guildid`);

