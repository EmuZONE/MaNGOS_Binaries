DELETE FROM mangos_string WHERE entry IN (167,168,466);
INSERT INTO mangos_string VALUES
(168,'Locations found are:\n%s',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
