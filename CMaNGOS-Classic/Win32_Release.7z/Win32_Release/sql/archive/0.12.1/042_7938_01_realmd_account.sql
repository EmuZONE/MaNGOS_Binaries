ALTER TABLE account
  CHANGE id id int(11) unsigned NOT NULL auto_increment COMMENT 'Identifier';
