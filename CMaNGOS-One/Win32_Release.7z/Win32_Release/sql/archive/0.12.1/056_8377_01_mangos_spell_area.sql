DELETE FROM `spell_area` where spell in (40216,42016);
