ALTER TABLE `corpse` ADD INDEX (`instance`);
ALTER TABLE `creature_respawn` ADD INDEX (`instance`);
ALTER TABLE `gameobject_respawn` ADD INDEX (`instance`);
