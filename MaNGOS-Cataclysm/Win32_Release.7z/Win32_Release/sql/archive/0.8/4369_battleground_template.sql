DELETE FROM `battleground_template` WHERE `id`='4';
INSERT INTO `battleground_template` VALUES ('4', '2', '10', '70', '929', '0', '936', '3.14159');
