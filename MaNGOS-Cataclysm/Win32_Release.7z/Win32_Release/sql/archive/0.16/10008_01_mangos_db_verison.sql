ALTER TABLE db_version CHANGE COLUMN required_9990_01_mangos_spell_chain required_10008_01_mangos_db_verison bit;

