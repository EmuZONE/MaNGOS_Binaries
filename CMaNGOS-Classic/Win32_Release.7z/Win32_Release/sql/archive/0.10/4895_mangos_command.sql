DELETE FROM command WHERE name IN ('tele');

INSERT INTO `command` VALUES
('tele',1,'Syntax: .tele #location\r\n\r\nTeleport player to a given location.');
