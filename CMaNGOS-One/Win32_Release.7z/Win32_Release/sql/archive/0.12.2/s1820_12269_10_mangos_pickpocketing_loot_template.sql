ALTER TABLE db_version CHANGE COLUMN required_s1820_12269_09_mangos_mail_loot_template required_s1820_12269_10_mangos_pickpocketing_loot_template bit;

ALTER TABLE mail_loot_template DROP COLUMN lootcondition, DROP COLUMN condition_value1, DROP COLUMN condition_value2;
