DELETE FROM `spell_proc_event` WHERE `entry` IN (29801,30030,30033);
INSERT INTO `spell_proc_event` VALUES
(29801,0,0,0,0,0,0,0),
(30030,0,0,0,0,0,0,0),
(30033,0,0,0,0,0,0,0);
