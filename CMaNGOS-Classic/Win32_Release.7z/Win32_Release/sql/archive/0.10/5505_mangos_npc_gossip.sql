-- Some unused columns left

ALTER TABLE `npc_gossip`
    DROP COLUMN `id`;
ALTER TABLE `npc_gossip`
    DROP COLUMN `gossip_type`;
ALTER TABLE `npc_gossip`
    DROP COLUMN `option_count`;
