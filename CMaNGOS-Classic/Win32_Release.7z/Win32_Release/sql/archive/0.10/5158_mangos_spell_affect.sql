DELETE FROM `spell_affect` WHERE `entry` IN (36591);
