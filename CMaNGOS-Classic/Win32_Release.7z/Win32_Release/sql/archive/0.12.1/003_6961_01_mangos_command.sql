DELETE FROM `command` WHERE name = 'reload';
