INSERT INTO `command` ( `name` , `security` , `help` )
VALUES (
'tele', '1', 'Syntax: .tele $location\n\nTeleport the gm to the provided location. You can look up these locations using .lookuptele'
);