ALTER  TABLE  locales_creature
    DROP subname_loc8;
