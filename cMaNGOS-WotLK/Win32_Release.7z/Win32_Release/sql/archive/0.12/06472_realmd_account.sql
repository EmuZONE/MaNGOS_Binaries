ALTER TABLE account
  CHARSET=utf8 COLLATE=utf8_general_ci;
