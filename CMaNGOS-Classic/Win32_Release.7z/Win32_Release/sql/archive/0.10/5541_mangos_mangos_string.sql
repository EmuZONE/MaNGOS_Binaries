DELETE FROM mangos_string WHERE entry in (580);
INSERT INTO mangos_string VALUES
(580,'Player %s learned all default spells for race/class and completed quests rewarded spells.',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
