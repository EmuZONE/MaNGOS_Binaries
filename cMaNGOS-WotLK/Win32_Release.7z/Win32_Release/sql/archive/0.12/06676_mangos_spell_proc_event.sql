DELETE FROM spell_proc_event where entry = 37447;
INSERT INTO spell_proc_event (entry, SchoolMask, Category, SkillID, SpellFamilyName, SpellFamilyMask, procFlags, ppmRate, cooldown) VALUES
(37447,0,0,0,3,0x0000010000000000,0x00004000,0,0);
