ALTER TABLE `creature_template`
  ADD COLUMN `heroic_entry` mediumint(8) unsigned NOT NULL default '0' AFTER entry;
