DELETE FROM spell_affect WHERE entry = '12606';
INSERT INTO spell_affect (entry, effectId, SpellFamilyMask) VALUES
(12606,0,0x0000000000002000);
