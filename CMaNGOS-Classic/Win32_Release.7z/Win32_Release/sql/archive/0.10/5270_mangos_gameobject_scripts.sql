ALTER TABLE `button_scripts` RENAME TO `gameobject_scripts`;
