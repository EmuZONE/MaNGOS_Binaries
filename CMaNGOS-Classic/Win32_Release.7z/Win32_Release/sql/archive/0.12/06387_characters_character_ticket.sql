ALTER TABLE `character_ticket`
  DROP `ticket_category`;
