DELETE FROM `spell_chain` WHERE `spell_id` IN (25477);

INSERT INTO `spell_chain` VALUES
(25477,19312,18137,7);
