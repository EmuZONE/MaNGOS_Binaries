DELETE FROM `spell_proc_event` WHERE `entry`=28305;
INSERT INTO `spell_proc_event` (`entry`, `SchoolMask`, `Category`, `SkillID`, `SpellFamilyName`, `SpellFamilyMask`, `procFlags`, `ppmRate`) VALUE
(28305,0,0,0,0,0x0000000000000000,0x00000001,0);
