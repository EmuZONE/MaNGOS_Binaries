DELETE FROM mangos_string WHERE entry in (355);

INSERT INTO mangos_string VALUES
 (355,'Title %u (%s) set as current selected title for player %s.',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
