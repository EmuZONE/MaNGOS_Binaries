ALTER TABLE `quest_template`
    CHANGE `ExclusiveGroup` `ExclusiveGroup` int(11) NOT NULL default '0';
