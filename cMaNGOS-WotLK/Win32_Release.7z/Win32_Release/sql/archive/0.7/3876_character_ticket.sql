ALTER TABLE `character_ticket` CHANGE `ticket_text` `ticket_text` text;
