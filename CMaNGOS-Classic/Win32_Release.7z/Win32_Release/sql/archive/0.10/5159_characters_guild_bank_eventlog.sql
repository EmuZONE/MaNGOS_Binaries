ALTER TABLE `guild_bank_eventlog`
  ADD KEY `guildid_key` (`guildid`);

