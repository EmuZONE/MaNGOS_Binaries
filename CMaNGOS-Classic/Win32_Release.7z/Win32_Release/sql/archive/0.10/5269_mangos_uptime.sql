ALTER TABLE `uptime`
  ADD COLUMN `maxplayers` int(11) unsigned NOT NULL default '0';
