DELETE FROM `spell_proc_event` WHERE `entry` IN ( 16880 );
INSERT INTO `spell_proc_event` VALUES
(16880,0,0,0,0,0,65536,0);

DELETE FROM `spell_proc_event` WHERE `entry` IN ( 40475 );
INSERT INTO `spell_proc_event` VALUES
(40475,0,0,0,0,0,524289,3);

DELETE FROM `spell_proc_event` WHERE `entry` IN ( 41434 );
INSERT INTO `spell_proc_event` VALUES
(41434,0,0,0,0,0,1,2);
