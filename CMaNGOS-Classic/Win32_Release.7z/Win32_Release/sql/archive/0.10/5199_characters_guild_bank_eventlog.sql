DELETE FROM `guild_bank_eventlog` WHERE `LogGuid`=0;
