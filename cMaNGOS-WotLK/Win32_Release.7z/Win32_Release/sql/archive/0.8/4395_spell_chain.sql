DELETE FROM `spell_chain` WHERE `spell_id` IN (27149);
INSERT INTO `spell_chain` VALUES
(27149,10293,465,8);

DELETE FROM `spell_chain` WHERE `spell_id` IN (27150);
INSERT INTO `spell_chain` VALUES
(27150,10301,7294,6);

DELETE FROM `spell_chain` WHERE `spell_id` IN (27151);
INSERT INTO `spell_chain` VALUES
(27151,19896,19876,4);

DELETE FROM `spell_chain` WHERE `spell_id` IN (27152);
INSERT INTO `spell_chain` VALUES
(27152,19898,19888,4);

DELETE FROM `spell_chain` WHERE `spell_id` IN (27153);
INSERT INTO `spell_chain` VALUES
(27153,19900,19891,4);

