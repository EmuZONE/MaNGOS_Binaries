ALTER TABLE db_version CHANGE COLUMN required_z2621_s2263_12823_01_mangos_command required_z2621_s2263_12823_02_mangos_creature_movement bit;

ALTER TABLE creature_movement DROP COLUMN wpguid;
