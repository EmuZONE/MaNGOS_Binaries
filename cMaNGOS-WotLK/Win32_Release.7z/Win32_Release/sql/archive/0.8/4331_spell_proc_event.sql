DELETE FROM `spell_proc_event` WHERE `entry` IN (974,32593,32594);
INSERT INTO `spell_proc_event` VALUES
(974,0,0,0,0,0,0x100402,0),
(32593,0,0,0,0,0,0x100402,0),
(32594,0,0,0,0,0,0x100402,0);

DELETE FROM `spell_proc_event` WHERE `entry` IN (2652,19261,19262,19264,19265,19266,25461);
INSERT INTO `spell_proc_event` VALUES
(2652, 0,0,0,0,0,0x2,0),
(19261,0,0,0,0,0,0x2,0),
(19262,0,0,0,0,0,0x2,0),
(19264,0,0,0,0,0,0x2,0),
(19265,0,0,0,0,0,0x2,0),
(19266,0,0,0,0,0,0x2,0),
(25461,0,0,0,0,0,0x2,0);
