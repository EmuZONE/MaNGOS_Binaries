ALTER TABLE `character_inventory`
   ADD KEY `idx_guid` ( `guid` );
