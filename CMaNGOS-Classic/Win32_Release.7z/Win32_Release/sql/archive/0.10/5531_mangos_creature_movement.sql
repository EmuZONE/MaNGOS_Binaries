ALTER TABLE `creature_movement`
    CHANGE COLUMN `id` `id` int(10) unsigned NOT NULL auto_increment COMMENT 'Creature GUID';
