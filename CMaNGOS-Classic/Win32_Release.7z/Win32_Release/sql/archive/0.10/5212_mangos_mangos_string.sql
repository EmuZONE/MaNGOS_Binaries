DELETE FROM `mangos_string` WHERE `entry` = 579;
INSERT INTO `mangos_string` VALUES
 (579,'Selected player or creature not have victim.',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
