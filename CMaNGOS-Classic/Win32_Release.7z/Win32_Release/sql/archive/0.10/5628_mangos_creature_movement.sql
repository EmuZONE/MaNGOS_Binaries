ALTER  TABLE  creature_movement
    DROP aiscript;
