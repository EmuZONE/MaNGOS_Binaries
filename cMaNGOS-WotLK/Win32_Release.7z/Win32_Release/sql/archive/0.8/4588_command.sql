DELETE FROM command WHERE name IN ('gameobject');
