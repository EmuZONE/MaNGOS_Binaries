ALTER TABLE `instance_template`
  ADD `parent` int(11) unsigned NOT NULL AFTER `map`;
