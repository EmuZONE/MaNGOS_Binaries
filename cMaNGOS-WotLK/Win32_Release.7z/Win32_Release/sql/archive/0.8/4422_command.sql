INSERT INTO `command` (`name`, `security`, `help`) VALUES ('npcwhisper', '1', 'Syntax: .npcwhisper #playerguid #text\r\nMake the selected npc whisper #text to  #playerguid.');
